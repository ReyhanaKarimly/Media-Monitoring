import scrapy


class MyFirstScraperSpider(scrapy.Spider):
    name = 'QSS'
    allowed_domains = ['qss.az/trainings']
    start_urls = ['http://www.qss.az/trainings']



    def parse(self, response):
        #Remove XML namespaces
        response.selector.remove_namespaces()

        #Extract article information
        courses= response.css('div.news-title a::text').getall()
        descriptions = response.css('p::text').getall()
        durations = response.css('div.col-lg-5.col-md-5.col-sm-5.col-xs-5.single-star-b.padding0::text').getall()
        links = response.css('div.col-lg-3.col-md-4.col-sm-4.col-xs-12.thumbnail a::attr(href)').getall()


        for i in range(len(links)):
            
            
            if links[i] !="http://dsa.az":
                links[i] ="http://dsa.az"+links[i]

        for item in zip(courses,descriptions,durations,links):
            scraped_info = {
                'Course' : item[0],
                'Description' : item[1],
                'Duration' : item[2],
                'link' : item[3]
            }

            yield scraped_info
